#include <stddef.h>
#include <stdlib.h>

#ifndef QUEUE_H
#define QUEUE_H

typedef struct node
{
    void *data;//数据域指针
    char Type;
    struct node *next;//指向当前结点的下一结点
} Node;

typedef struct Lqueue
{
    Node *front;//队头
    Node *rear; //队尾
    size_t length; //队列长度
} LQueue;

typedef enum
{
    FALSE=0, 
    TRUE=1
} Status;

void Input(char* input,void** output,char* type);

void InitLQueue(LQueue *Q);//初始化队列
void DestoryLQueue(LQueue *Q);//销毁队列
Status IsEmptyLQueue(const LQueue *Q);//检查队列是否为空
Status GetHeadLQueue(LQueue *Q, void **e);//查看队头元素
int LengthLQueue(LQueue *Q);//确定队列长度
Status EnLQueue(LQueue *Q,void *Data, char type);//入队
Status DeLQueue(LQueue *Q);//出队
void ClearLQueue(LQueue *Q);//清空队列
Status TraverseLQueue(const LQueue *Q, void (*foo)(void *q,char type));
void LPrint(void *q,char type);//操作队列

#endif