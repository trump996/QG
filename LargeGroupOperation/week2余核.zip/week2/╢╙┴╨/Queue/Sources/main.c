#include "..\Headers\Queue.h"
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <windows.h>

void Menu_Display(void)
{
    printf("*****1.建立一个队列*****\n");
    printf("*****2.入队*************\n");
    printf("*****3.出队*************\n");
    printf("*****4.获取队头元素*****\n");
    printf("*****5.清空队列*********\n");
    printf("*****6.销毁队列*********\n");
    printf("*****7.退出系统*********\n");
}

void* User_Input(char* Typein)
{
    char input[100];
    void* output=NULL;
    char type='\0';

    gets(input);
    int len=strlen(input);

    if(len==1&&input[0]=='\n')
        printf("输入为空\n");

    Input(input,&output,&type);
    switch(type)
    {
        case 'c':
        {
            *Typein=type;
            //output=(void*)malloc(sizeof(char));
            //Input(input,&output,&type);
            char* inputchar=(char*)output;
            //free(output);
            return inputchar;
        }
        break;

        case 'f':
        {
            *Typein=type;
            //output=(void*)malloc(sizeof(float));
            //Input(input,&output,&type);
            float* inputfloat=(float*)output;
            //free(output);
            return inputfloat;
        }
        break;

        case 'i':
        {
            *Typein=type;
            //output=(void*)malloc(sizeof(int));
            //Input(input,&output,&type);
            int* inputint=(int*)output;
            //free(output);
            return inputint;
        }
        break;
    }
}

int main(void)
{
    bool State=0;//栈是否存在
    int Choice,Value_INT;
    float Value_FLOAT;
    char Value_CHAR,TYPE='\0';
    LQueue MY_Queue;

    SetConsoleOutputCP(65001);

    printf("欢迎进入队列管理系统半桶水版！\n");
    Menu_Display();
    printf("请输入您想进行的操作对应的选项\n");
    printf("**温馨提示：在操作选项中输入浮点数会按取整后的整数处理！**\n");
    printf("**温馨提示：显示队列时，浮点数只显示到小数点后三位！**\n");

    while(1)
    {
        if(scanf("%d",&Choice)==1)
        {
            getchar();
            switch (Choice)
            {
                case 1://建立一个空的队列
                {
                    if(State==1)
                        printf("队列已经存在\n");
                    else
                    {
                        InitLQueue(&MY_Queue);
                        State=1;
                        printf("队列已经建立\n");
                    }
                }
                break;

                case 2://入队
                {
                    if(State==1)
                    {
                        printf("请先输入你想要入队的数据，仅限于整形、浮点数或者单字符\n");
                        void* value=User_Input(&TYPE);
                        switch (TYPE)
                        {
                            case 'c':
                            {
                                //char* value=(char*)malloc(sizeof(char));
                                char* charvalue=(char*)value;
                                //value=(char*)User_Input(&TYPE);
                                EnLQueue(&MY_Queue,charvalue,'c');
                                //free(value);

                                printf("入队完毕，当前队列如下所示：\n");
                                TraverseLQueue(&MY_Queue,LPrint);
                            }
                            break;

                            case 'f':
                            {
                                //float* value=(float*)malloc(sizeof(char));
                                float* floatvalue=(float*)value;
                                //value=(float*)User_Input(&TYPE);
                                EnLQueue(&MY_Queue,floatvalue,'f');
                                //free(value);

                                printf("入队完毕，当前队列如下所示：\n");
                                TraverseLQueue(&MY_Queue,LPrint);
                            }
                            break;

                            case 'i':
                            {
                                //int* value=(int*)malloc(sizeof(char));
                                int* intvalue=(int*)value;
                                //value=(int*)User_Input(&TYPE);
                                EnLQueue(&MY_Queue,intvalue,'i');
                                //free(value);

                                printf("入队完毕，当前队列如下所示：\n");
                                TraverseLQueue(&MY_Queue,LPrint);
                            }
                            break;
                        }
                    }
                    else
                        printf("老弟你队列呢老弟\n");
                }
                break;

                case 3://出队
                {
                    if(State==1)
                    {
                        if(IsEmptyLQueue(&MY_Queue)==TRUE)
                        {
                            printf("当前链表为空，无法出队，请继续选择你想进行的操作\n");
                        }
                        else
                        {
                            DeLQueue(&MY_Queue);
                            printf("出队成功，当前队列如下所示：\n");
                            TraverseLQueue(&MY_Queue,LPrint);
                        }
                    }
                    else
                        printf("老弟你队列呢老弟\n");
                }
                break;

                case 4:
                {
                    if(State==1)
                    {
                        void* Data;
                        GetHeadLQueue(&MY_Queue,&Data);
                        switch (MY_Queue.front->Type)
                        {
                            case 'i':
                                printf("%d\n",*(int*)Data);
                            break;
                            case 'c':
                                printf("%c\n",*(char*)Data);
                            break;
                            case 'f':
                                printf("%.3f\n",*(float*)Data);
                            break;
                        }
                    }
                    else
                        printf("老弟你队列呢老弟\n");
                }
                break;

                case 5:
                {
                    if(State==1)
                    {
                        ClearLQueue(&MY_Queue);
                        printf("清空队列完毕\n");
                    }
                    else
                        printf("老弟你队列呢老弟\n");
                }
                break;

                case 6:
                {
                    if(State==1)
                    {
                        DestoryLQueue(&MY_Queue);
                        State=0;
                        printf("销毁队列完毕\n");
                    }
                    else
                        printf("老弟你队列呢老弟\n");
                }
                break;

                case 7:
                {
                    if(State==1)
                        printf("请先销毁已存在的队列再退出系统\n");
                    else
                        return 0;
                }
                break;
            }
        }
        else if(scanf("%f",&Value_FLOAT)==1)
            Choice=(int)Value_FLOAT;
        else if(scanf("%c",&Value_CHAR)==1)
            printf("输入选项啊老弟，别乱输\n");
        else
            printf("输入选项啊老弟，别乱输\n");
    }
}