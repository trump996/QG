#include "..\Headers\Queue.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

void Input(char* input,void** output,char* type)
{
    int InteCount=0,DeciCount=0,CharCount=0;

    for(int i=0;input[i]!='\0';i++)
    {
        if(isdigit(input[i]))
            InteCount++;
        else if(input[i]=='.')
        {
            DeciCount++;
            if(DeciCount>=2)
            {
                printf("输入错误\n");
                return;
            }
        }
        else if(isspace(input[i]))
            continue;
        else
            CharCount++;
    }

    if(CharCount==1&&!isdigit(input[0]))
    {
        *type='c';
        *output=&input[0];
    }
    else if (DeciCount==1)
    {
        *type='f';
        float acc=atof(input);
        *output=&acc;
    }
    else if(InteCount>0)
    {
        *type='i';
        int acc=atoi(input);
        *output=&acc;
    }
    else
    {
        *type=0;
        printf("输入错误\n");
    }
}

void InitLQueue(LQueue *Q)
{
    Q->front=NULL;
    Q->rear=NULL;
    Q->length=0;
}

void DestoryLQueue(LQueue *Q)
{
    if(Q==NULL)
        return;

    while (Q->front!=NULL)
    {
        Node* Current=Q->front;
        Q->front=Q->front->next;
        free(Current->data);
        free(Current);
    }
}

Status IsEmptyLQueue(const LQueue *Q)
{
    if(Q==NULL)
        return FALSE;

    if(Q->front==NULL)
        return TRUE;
}

Status GetHeadLQueue(LQueue *Q, void **e)//查看队头元素
{
    if(Q==NULL)
        return FALSE;
    else
    {
        switch (Q->front->Type)
        {
            case 'i':
                *e=Q->front->data;
            break;
            case 'c':
                *e=Q->front->data;
            break;
            case 'f':
                *e=Q->front->data;
            break;           
        }
    }
    return TRUE;
}

int LengthLQueue(LQueue *Q)//确定队列长度
{
    return Q->length;
}

Status EnLQueue(LQueue *Q,void *Data, char typeee)//入队
{
    if(Q==NULL)
        return FALSE;

    Node* New=(Node*)malloc(sizeof(Node));
    if(New==NULL)
        return FALSE;

    switch (typeee)
    {
        case 'i':
        {
            New->data=malloc(sizeof(int));
            if(New->data==NULL)
                free(New);
            memcpy(New->data,Data,sizeof(int));
        }
        break;

        case 'c':
        {
            New->data=malloc(sizeof(char)+1);
            if(New->data==NULL)
                free(New);
            memcpy(New->data,Data,sizeof(char));
        }
        break;

        case 'f':
        {
            New->data=malloc(sizeof(float));
            if(New->data==NULL)
                free(New);
            memcpy(New->data,Data,sizeof(float));
        }
        break;
    }

    //New->data=Data;
    New->Type=typeee;
    New->next=NULL;

    if(Q->rear==NULL)
        Q->front=Q->rear=New;
    else
    {
        Q->rear->next=New;
        Q->rear=New;
    }
    Q->length++;

    return TRUE;
}   

Status DeLQueue(LQueue *Q)//出队
{
    if(Q==NULL)
        return FALSE;
    
    Node* Temp=Q->front;
    Q->front=Q->front->next;

    if(Q->front==NULL)
        Q->rear=NULL;
    
    free(Temp->data);
    free(Temp);

    Q->length--;
}

void ClearLQueue(LQueue *Q)//清空队列
{
    while (Q->front!=NULL)
    {
        Node* Current=Q->front;
        Q->front=Q->front->next;
        free(Current->data);
        free(Current);
    }

    Q->front=Q->rear=NULL;
    Q->length=0;
}

void LPrint(void *q,char type)//操作队列
{
    switch (type)
    {
        case 'i':
        printf("%d-",*(int *)q);
        break;

        case 'c':
        printf("%c-",*(char *)q);
        break;

        case 'f':
        printf("%.3f-",*(float *)q);
        break;
    }
}

Status TraverseLQueue(const LQueue *Q, void (*foo)(void *q,char type))
{
    if(Q==NULL)
        return FALSE;

    Node* Current=Q->front;
    while(Current!=NULL)
    {
        foo(Current->data,Current->Type);
        Current=Current->next;
    }
    putchar('\n');
    return TRUE;
}