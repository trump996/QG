#include "..\Headers\Calculator.h"
#include "..\Headers\Stack.h"
#include <stdio.h>
#include <stdbool.h>
#include <windows.h>

int main(void)
{
    SetConsoleOutputCP(65001);

    char input[100],output[100];
    int resultnum;

    printf("****欢迎进入四则运算计算器严重阉割战损版！**********************\n");
    printf("****在这里你可以输入一个四则运算表达式，我们会将结果反馈给你****\n");
    printf("****但是由于是阉割战损版，您只能实现整数的四则运算**************\n");
    printf("****并且当您实现除法运算时，您得到的结果是经过取整的************\n");
    printf("您可以通过输入out来退出系统\n");
    while (1)
    {
        printf("请输入您的表达式：\n");
        fgets(input,100*sizeof(char),stdin);

        if(strcmp(input,"out\n")==0)
            return 0;

        if(Transform(input,output)==SUCCESS)
        {
            resultnum=Calcul(output);
            printf("您的结果为：%d\n",resultnum);
        }
        else
            printf("输入错误，请重新输入\n");
    }
}