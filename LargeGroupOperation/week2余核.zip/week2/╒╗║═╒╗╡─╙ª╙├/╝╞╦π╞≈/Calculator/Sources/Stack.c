#include "..\Headers\Stack.h"
#include <stdio.h>
#include <stdlib.h>

Status initLStack(LinkStack *s)
{
    if(s==NULL)
        return ERROR;
    
    s->top=NULL;
    s->count=0;

    return SUCCESS;
}

Status isEmptyLStack(LinkStack *s)
{
    if(s->top==NULL)
        return SUCCESS;//栈确实为空
    else
        return ERROR;
}

Status getTopLStack(LinkStack *s,int *e)
{
    if (s->top==NULL)
        return ERROR;
    else
    {
        *e=s->top->data;
        return SUCCESS;
    }
}

Status clearLStack(LinkStack *s)//清空栈
{
    if(s==NULL||s->top==NULL)
        return ERROR;
    else
    {
        LinkStackPtr Current=s->top;

        while (Current!=NULL)
        {
            LinkStackPtr Next=Current->next;

            free(Current);
            Current=Next;
        }

        s->top=NULL;
        s->count=0;
    }
}

Status destroyLStack(LinkStack *s)
{
    if(s==NULL||s->top==NULL)
        return ERROR;
    else
    {
        clearLStack(s);
        free(s);
    }
}

Status LStackLength(LinkStack *s,int *length)
{
    if(s==NULL)
        return ERROR;

    *length=s->count;
}

Status pushLStack(LinkStack *s,int data)
{
    if(s==NULL)
        return ERROR;

    LinkStackPtr New=malloc(sizeof(StackNode));

    if(New==NULL)
        return ERROR;

    New->data=data;
    New->next=s->top;
    s->top=New;
    s->count++;

    return SUCCESS;
}

Status popLStack(LinkStack *s,int *data)
{
    if(s==NULL)
        return ERROR;
    
    LinkStackPtr Temp=s->top;
    *data=Temp->data;
    s->top=Temp->next;

    free(Temp);
    s->count--;
}

void PrintStack(LinkStack *s)
{
    if(s==NULL)
        return;
    
    LinkStackPtr Current=s->top;

    while (Current!=NULL)
    {
        printf("%d ",Current->data);
        Current=Current->next;
    }
    putchar('\n');
}