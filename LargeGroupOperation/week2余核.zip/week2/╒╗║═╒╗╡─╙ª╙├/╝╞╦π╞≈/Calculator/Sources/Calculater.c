#include "..\Headers\Calculator.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

Status IS_OP(char ch)
{
    if(ch == '(' || ch == ')' || ch == '+' || ch == '-' || ch == '*' || ch == '/')
        return SUCCESS;
    else
        return ERROR;
}

int Get_Pre(char op)
{
    if(op=='+'||op=='-')
        return 1;
    else if(op=='*'||op=='/')
        return 2;
    else 
        return 0;
}

Status Transform(char* input,char output[])
{
    LinkStack OP_Stack;
    initLStack(&OP_Stack);
    int left=0,right=0;

    int i=0;
    int popdata=0;

    while(*input!='\n')
    {
        if(*input>='0'&&*input<='9')
        {
            while (*input>='0'&&*input<='9')
            {
                output[i++]=*input;
                input++;
            }
            output[i++]='#';
        }
        else if(IS_OP(*input))
        {
            if(isEmptyLStack(&OP_Stack))
            {
                if(*input==')')
                    return ERROR;

                if(*input=='(')
                    left++;

                pushLStack(&OP_Stack,*input);
                input++;
            }
            else
            {
                if(*input=='(')
                {
                    left++;
                    pushLStack(&OP_Stack,*input);
                    input++;
                }
                else if(*input==')')
                {
                    right++;
                    while (!isEmptyLStack(&OP_Stack))
                    {
                        popLStack(&OP_Stack,&popdata);

                        if(popdata=='(')
                            break;

                        output[i++]=popdata;
                    }
                    input++;
                }
                else
                {
                    getTopLStack(&OP_Stack,&popdata);
                    if(Get_Pre(popdata)<Get_Pre(*input))
                    {
                        pushLStack(&OP_Stack,*input);
                    }
                    else
                    {
                        popLStack(&OP_Stack,&popdata);
                        output[i++]=popdata;
                        pushLStack(&OP_Stack,*input);
                    }
                    input++;
                }
            }
        }
        else
        {
            return ERROR;
        }
    }

    if(left!=right)
        return ERROR;

    while(!isEmptyLStack(&OP_Stack))
    {
        popLStack(&OP_Stack,&popdata);
        output[i++]=popdata;
    }
    output[i]='\0';

    destroyLStack(&OP_Stack);

    return SUCCESS;
}

int Operate(int a,int b,char op)
{
    switch (op)
    {
        case '+':
        return a+b;

        case '-':
        return a-b;

        case '*':
        return a*b;

        case '/':
        return b!=0?a/b:0;
    }
}

int Calcul(char* postfix)
{
    LinkStack NUM_Stack;
    initLStack(&NUM_Stack);

    int pop1,pop2;
    int result;

    while (*postfix!='\0')
    {
        if(IS_OP(*postfix))
        {
            popLStack(&NUM_Stack,&pop1);
            popLStack(&NUM_Stack,&pop2);

            result=Operate(pop2,pop1,*postfix);

            pushLStack(&NUM_Stack,result);

            postfix++;
        }
        else
        {
            int d=0;
            while(*postfix>='0'&&*postfix<='9')
            {
                d=10*d+(*postfix)-'0';
                postfix++;
            }
            pushLStack(&NUM_Stack,d);
            postfix++;
        }
    }
    popLStack(&NUM_Stack,&pop1);
    destroyLStack(&NUM_Stack);
    return pop1;
}