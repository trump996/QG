#ifndef STACK_H
#define STACK_H

typedef enum Status 
{
    ERROR = 0, 
	SUCCESS = 1
} Status;

typedef struct StackNode
{
	int data;
	struct StackNode *next;
}StackNode, *LinkStackPtr;

typedef struct LinkStack
{
	LinkStackPtr top;
	int	count;
}LinkStack;

Status initLStack(LinkStack *s);
Status isEmptyLStack(LinkStack *s);
Status getTopLStack(LinkStack *s,int *e);
Status clearLStack(LinkStack *s);
Status destroyLStack(LinkStack *s);
Status LStackLength(LinkStack *s,int *length);
Status pushLStack(LinkStack *s,int data);
Status popLStack(LinkStack *s,int *data);

void PrintStack(LinkStack *s);

#endif