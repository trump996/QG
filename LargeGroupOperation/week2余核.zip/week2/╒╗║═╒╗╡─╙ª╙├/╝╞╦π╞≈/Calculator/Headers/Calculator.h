#include "..\Headers\Stack.h"

#ifndef CALCULATER_H
#define CALCULATER_H

Status Transform(char* input,char output[]);
int Calcul(char* postfix);

#endif