#include <REGX52.H>
#include "led.h"
#include "key.h"
#include "bell.h"
#include "nixie.h"
#include "delay.h"

void main(void)
{
	while(1)
    {
        if(P3_1==0)
        {
            Delay(20);
            while(P3_1==0);
            Delay(20);
            Buzzer_Time(500);
        }
				
				if(P3_0==0)
				{
						Delay(20);
            while(P3_1==0);
            Delay(20);
            LED_Floor();
				}
				
				if(P3_2==0)
				{
						Delay(20);
            while(P3_1==0);
            Delay(20);
            NixTube_Add();
				}
    }
}
