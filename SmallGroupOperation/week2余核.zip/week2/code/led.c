#include "led.h"
#include "delay.h"

void LED_Floor(void)
{
	P2=0xFE;
	Delay(500);
	P2=0xFD;
	Delay(500);
	P2=0xFB;
	Delay(500);
	P2=0xF7;
	Delay(500);
	P2=0xEF;
	Delay(500);
	P2=0xDF;
	Delay(500);
	P2=0xBF;
	Delay(500);
	P2=0x7F;
	Delay(500);
	P2=0xFF;
}