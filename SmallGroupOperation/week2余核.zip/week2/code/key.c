#include "key.h"
#include "delay.h"

int Key_Control(void)
{
	if(P3_1==0)
	{
			Delay(20);
			while(P3_1==0);
			Delay(20);
			return 1;
	}
	else if(P3_0==0)
	{
			Delay(20);
			while(P3_0==0);
			Delay(20);
			return 2;
	}
	else if(P3_2==0)
	{
			Delay(20);
			while(P3_2==0);
			Delay(20);
			return 3;
	}
	else if(P3_3==0)
	{
			Delay(20);
			while(P3_3==0);
			Delay(20);
			return 4;
	}
	else
		return 0;
}