#ifndef NIXIE_H
#define NIXIE_H

void NixTube(unsigned char Location,Number);
void NixTube_Add(void);

#endif
