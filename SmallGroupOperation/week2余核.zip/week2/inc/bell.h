#include <REGX52.H>
#include <INTRINS.H>

sbit BUZZER=P2^5;

void Buzzer_Time(unsigned int ms);
