#include <REGX52.H>

int Key_Control(void);