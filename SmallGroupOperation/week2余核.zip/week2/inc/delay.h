#include <REGX52.H>

void Delay(unsigned int x);
