#include <REGX52.H>
#include "uart.h"

void UART_Init(void)
{
	SCON = 0x50;
	PCON |= 0x80;
	TMOD &= 0x0F;
	TMOD |= 0x20;
	TL1 = 0xF4;
	TH1 = 0xF4;
	TR1 = 1;
	ET1 = 0;
	ES = 1;
	PS = 1;
	EA = 1;
}