#ifndef __UART_H__
#define __UART_H__

void UART_Init(void);

#endif