#include <REGX52.H>
#include "uart.h"
#include "Delay.h"
#include "nixtube.h"

unsigned long int Num;

void main(void)
{
	UART_Init();
	while(1)
	{
		int i;
		unsigned long int Display = Num;
		for(i=1; Display>0; i++,Display/=10)
		{
			NixTube(9-i,Display%10);
		}
	}
}

void UART_Routine(void) interrupt 4
{
	if(RI==1)
	{
		Num = SBUF;
		RI = 0;
	}
	if(TI==1)
	{
		TI = 0;
	}
}