#include <REGX52.H>
#include "key.h"
#include "timer.h"
#include <INTRINS.H>
#include "uart.h"
#include "Delay.h"
#include "nixtube.h"

unsigned char keynum;
char keystate=0;
int Timer0_Count = 0;
int Num=0;
char i;

void main(void)
{
	Timer0_Init();
	UART_Init();
	
	while(1)
	{
		keynum = Key();
		if(keynum==1)//LED��˸
		{
			P2 = 0xFF;
			keystate=1;
		}
		if(keynum==2)//LED��ˮ��
		{
			P2 = 0xFE;
			keystate=2;
		}
	}
}

//10�����һ��
void Timer0_Rountine(void) interrupt 1
{
	TL0 = 0xF0;
	TH0 = 0xD8;
	
	Timer0_Count++;
	
	if(Timer0_Count>=100)
	{
		Timer0_Count = 0;
		if(keystate==1)
		{
			P2_0 = !P2_0;
		}
		if(keystate==2)
		{
			P2=_crol_(P2,1);
		}
		
		UART_SendString("helloworld\r\n");
		
		ES = 1;
		ES = 0;
	}
}

void UART_Routine(void) interrupt 4
{
	if(RI==1)
	{
		Num = SBUF;
		RI = 0;
	}
	if(TI==1)
	{
		TI = 0;
	}
}