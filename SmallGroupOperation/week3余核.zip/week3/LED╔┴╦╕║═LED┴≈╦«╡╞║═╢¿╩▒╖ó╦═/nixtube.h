#ifndef __NIXTUBE_H__
#define __NIXTUBE_H__

void NixTube(unsigned char Location,Number);

#endif