#ifndef __KET_H__
#define __KET_H__

unsigned char Key(void);

#endif